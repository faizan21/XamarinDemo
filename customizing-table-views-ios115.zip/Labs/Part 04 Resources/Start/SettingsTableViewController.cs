using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace WeatherSettings
{
	partial class SettingsTableViewController : UITableViewController
	{
		public SettingsTableViewController (IntPtr handle) : base (handle)
		{
		}
	}
}
